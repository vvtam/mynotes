## Notice

1.0.48版本的一个变化

- The `NLST` command doesn't perform globbing any more.